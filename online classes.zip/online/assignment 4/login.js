function login() {
   const enteredPhone = parseInt(document.getElementById("number").value);
const enteredPass = document.getElementById("password").value;

    const result = document.getElementById("res");

    // Database (Ideally, this would be in a secure backend)
    const phone = 1234;
    const pass = "test";

    function checkPhone(n, callback) {
        if (n === phone) {
            callback(true);
        } else {
            callback(false);
        }
    }

    function checkPass(p, callback) {
        if (p === pass) {
            callback(true);
        } else {
            callback(false);
        }
    }

    checkPhone(enteredPhone, (isnum) => {
        if (isnum) {
            checkPass(enteredPass, (ispass) => {
                if (ispass) {
                    result.style.color = "green";
                    result.innerText = "Login successful";
                } else {
                    result.style.color = "yellow";
                    result.innerText = "Invalid password"; // More specific message
                }
            });
        } else {
            result.style.color = "red";
            result.innerText = "Invalid phone number"; // More specific message
        }
    });
}
